import Link from "next/link"

const footerLinks = {
  producto: [
    { href: "/", label: "Sistema de facturación" },
    { href: "/como-usar-la-plataforma", label: "Tutoriales" },
    { href: "/sistema-pos", label: "Sistema POS" },
    { href: "/sistema-de-inventario", label: "Sistema de inventario" },
    { href: "/facturacion-online", label: "Facturación online" },
    { href: "/punto-de-venta-abarrotes", label: "Punto de venta abarrotes" },
    { href: "/app-movil", label: "App Móvil Android" },
    { href: "/pricing", label: "Precios" },
    { href: "/about", label: "Nosotros" },
  ],
  legal: [
    { href: "/privacy", label: "Privacidad" },
    { href: "/terms", label: "Términos" },
    { href: "/sitemap.xml", label: "Sitemap" },
  ],
  empresa: [
    { href: "/about", label: "Nosotros" },
    { href: "/como-usar-la-plataforma", label: "Tutoriales" },
  ],
}

export function MarketingFooter() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="text-lg font-bold mb-2">MOVOPos</div>
            <p className="text-sm text-muted-foreground">
              Sistema de punto de venta e inventario para tu negocio.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-4">Producto</h3>
            <ul className="space-y-3">
              {footerLinks.producto.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-4">Legal</h3>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-4">Empresa</h3>
            <ul className="space-y-3">
              {footerLinks.empresa.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} MOVOPos. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
