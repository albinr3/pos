"use server"

import { prisma } from "@/lib/db"
import { Decimal } from "@prisma/client/runtime/library"
import { getCurrentSuperAdmin, logSuperAdminAction } from "@/lib/super-admin-auth"
import { processBillingEngine } from "@/lib/billing"
import { revalidatePath } from "next/cache"
import { hash } from "bcryptjs"
import { clerkClient } from "@clerk/nextjs/server"
import type {
  BillingStatus,
  BillingCurrency,
  BillingProvider,
  RegistrationDeviceType,
  RegistrationMethod,
} from "@prisma/client"

export async function resetUserPassword(
  userId: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const normalizedPassword = newPassword.trim()
    if (normalizedPassword.length < 6) {
      return { success: false, error: "La contraseña debe tener al menos 6 caracteres" }
    }

    const admin = await getCurrentSuperAdmin()
    if (!admin || !admin.canManageAccounts) {
      return { success: false, error: "No tienes permisos para restablecer contraseñas" }
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { account: true },
    })

    if (!user) {
      return { success: false, error: "Usuario no encontrado" }
    }

    const hashedPassword = await hash(normalizedPassword, 12)

    await prisma.user.update({
      where: { id: userId },
      data: { passwordHash: hashedPassword },
    })

    await logSuperAdminAction(admin.id, "reset_user_password", {
      targetAccountId: user.accountId,
      metadata: {
        targetUserId: user.id,
        username: user.username
      },
    })

    revalidatePath("/super-admin")
    revalidatePath(`/super-admin/accounts/${user.accountId}`)

    return { success: true }
  } catch (error) {
    console.error("Error resetting password:", error)
    return { success: false, error: "Error al restablecer la contraseña" }
  }
}

export async function resetPrimaryAccountPassword(
  accountId: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const normalizedPassword = newPassword.trim()
    if (normalizedPassword.length < 8) {
      return { success: false, error: "La contraseña debe tener al menos 8 caracteres" }
    }

    const admin = await getCurrentSuperAdmin()
    if (!admin || !admin.canManageAccounts) {
      return { success: false, error: "No tienes permisos para cambiar la contraseña principal" }
    }

    const account = await prisma.account.findUnique({
      where: { id: accountId },
      select: { id: true, name: true, clerkUserId: true },
    })

    if (!account) {
      return { success: false, error: "Cuenta no encontrada" }
    }

    const client = await clerkClient()
    await client.users.updateUser(account.clerkUserId, {
      password: normalizedPassword,
      signOutOfOtherSessions: true,
    })

    await logSuperAdminAction(admin.id, "reset_primary_account_password", {
      targetAccountId: account.id,
      metadata: {
        clerkUserId: account.clerkUserId,
      },
    })

    revalidatePath("/super-admin")
    revalidatePath("/super-admin/accounts")
    revalidatePath(`/super-admin/accounts/${account.id}`)

    return { success: true }
  } catch (error) {
    console.error("Error resetting primary account password:", error)
    return { success: false, error: "No se pudo cambiar la contraseña del acceso principal" }
  }
}


// ==========================================
// TYPES
// ==========================================

export type AccountListItem = {
  id: string
  name: string
  createdAt: Date
  clerkUserId: string
  registeredFromDevice: RegistrationDeviceType
  registeredWithMethod: RegistrationMethod

  // Billing info
  status: BillingStatus
  currency: BillingCurrency
  provider: BillingProvider
  trialEndsAt: Date | null
  currentPeriodEndsAt: Date | null
  graceEndsAt: Date | null
  priceDopCents: number
  priceUsdCents: number

  // Owner info
  ownerEmail: string | null
  ownerName: string | null

  // Stats
  usersCount: number
  productsCount: number
  salesCount: number
  lastPaymentAt: Date | null
}

export type AccountDetail = AccountListItem & {
  // Company Settings
  companyName: string | null
  companyPhone: string | null
  companyAddress: string | null
  logoUrl: string | null

  // Billing Profile
  billingLegalName: string | null
  billingTaxId: string | null
  billingAddress: string | null
  billingEmail: string | null
  billingPhone: string | null

  // Users
  users: {
    id: string
    name: string
    username: string
    role: string
    isOwner: boolean
    isActive: boolean
    createdAt: Date
  }[]

  // Payment History
  payments: {
    id: string
    amountCents: number
    currency: BillingCurrency
    status: string
    createdAt: Date
    paidAt: Date | null
    proofsCount: number
  }[]

  // Products
  products: {
    id: string
    productId: number
    name: string
    sku: string | null
    priceCents: number
    costCents: number
    stock: number
    productKind: string
    unit: string
    isActive: boolean
    createdAt: Date
  }[]

  // Subscription details
  subscriptionId: string | null
  manualVerificationStatus: string | null
  lemonCustomerId: string | null
  lemonSubscriptionId: string | null

  // Billing Plan
  billingPlanId: string | null
  billingPlanName: string | null

  // Onboarding
  onboardingCompleted: boolean
  onboardingCompletedAt: Date | null
  onboardingFirstSeenAt: Date | null
  onboardingLastSkippedAt: Date | null
  onboardingFirstProductId: string | null
  onboardingFirstSaleId: string | null
}

// ==========================================
// GET ACCOUNTS
// ==========================================

export async function getAccounts(): Promise<AccountListItem[]> {
  const accounts = await prisma.account.findMany({
    include: {
      billingSubscription: {
        include: {
          payments: {
            where: { status: "PAID" },
            orderBy: { paidAt: "desc" },
            take: 1,
          },
        },
      },
      billingProfile: true,
      users: {
        where: { isOwner: true },
        take: 1,
      },
      _count: {
        select: {
          users: true,
          products: true,
          sales: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
  })

  return accounts.map((account) => {
    const sub = account.billingSubscription
    const owner = account.users[0]
    const lastPayment = sub?.payments[0]

    return {
      id: account.id,
      name: account.name,
      createdAt: account.createdAt,
      clerkUserId: account.clerkUserId,
      registeredFromDevice: account.registeredFromDevice,
      registeredWithMethod: account.registeredWithMethod,

      status: sub?.status || "BLOCKED",
      currency: sub?.currency || "DOP",
      provider: sub?.provider || "MANUAL",
      trialEndsAt: sub?.trialEndsAt || null,
      currentPeriodEndsAt: sub?.currentPeriodEndsAt || null,
      graceEndsAt: sub?.graceEndsAt || null,
      priceDopCents: sub?.priceDopCents || 130000,
      priceUsdCents: sub?.priceUsdCents || 2000,

      ownerEmail: account.billingProfile?.email || owner?.email || null,
      ownerName: owner?.name || null,

      usersCount: account._count.users,
      productsCount: account._count.products,
      salesCount: account._count.sales,
      lastPaymentAt: lastPayment?.paidAt || null,
    }
  })
}

// ==========================================
// GET ACCOUNT DETAIL
// ==========================================

export async function getAccountDetail(accountId: string): Promise<AccountDetail | null> {
  const account = await prisma.account.findUnique({
    where: { id: accountId },
    include: {
      billingSubscription: {
        include: {
          payments: {
            include: {
              proofs: true,
            },
            orderBy: { createdAt: "desc" },
          },
          billingPlan: true,
        },
      },
      billingProfile: true,
      companySettings: true,
      onboarding: true,
      users: {
        orderBy: [{ isOwner: "desc" }, { createdAt: "asc" }],
      },
      products: {
        orderBy: [{ productId: "asc" }],
        take: 500,
        select: {
          id: true,
          productId: true,
          name: true,
          sku: true,
          priceCents: true,
          costCents: true,
          stock: true,
          productKind: true,
          unit: true,
          isActive: true,
          createdAt: true,
        },
      },
      _count: {
        select: {
          users: true,
          products: true,
          sales: true,
          customers: true,
        },
      },
    },
  })

  if (!account) return null

  const sub = account.billingSubscription
  const onboarding = account.onboarding
  const owner = account.users.find((u) => u.isOwner)
  const lastPayment = sub?.payments.find((p) => p.status === "PAID")

  return {
    id: account.id,
    name: account.name,
    createdAt: account.createdAt,
    clerkUserId: account.clerkUserId,
    registeredFromDevice: account.registeredFromDevice,
    registeredWithMethod: account.registeredWithMethod,

    // Billing
    status: sub?.status || "BLOCKED",
    currency: sub?.currency || "DOP",
    provider: sub?.provider || "MANUAL",
    trialEndsAt: sub?.trialEndsAt || null,
    currentPeriodEndsAt: sub?.currentPeriodEndsAt || null,
    graceEndsAt: sub?.graceEndsAt || null,
    priceDopCents: sub?.priceDopCents || 130000,
    priceUsdCents: sub?.priceUsdCents || 2000,
    subscriptionId: sub?.id || null,
    manualVerificationStatus: sub?.manualVerificationStatus || null,
    lemonCustomerId: sub?.lemonCustomerId || null,
    lemonSubscriptionId: sub?.lemonSubscriptionId || null,

    // Owner
    ownerEmail: account.billingProfile?.email || owner?.email || null,
    ownerName: owner?.name || null,

    // Stats
    usersCount: account._count.users,
    productsCount: account._count.products,
    salesCount: account._count.sales,
    lastPaymentAt: lastPayment?.paidAt || null,

    // Company Settings
    companyName: account.companySettings?.name || null,
    companyPhone: account.companySettings?.phone || null,
    companyAddress: account.companySettings?.address || null,
    logoUrl: account.companySettings?.logoUrl || null,

    // Billing Profile
    billingLegalName: account.billingProfile?.legalName || null,
    billingTaxId: account.billingProfile?.taxId || null,
    billingAddress: account.billingProfile?.address || null,
    billingEmail: account.billingProfile?.email || null,
    billingPhone: account.billingProfile?.phone || null,

    // Users
    users: account.users.map((u) => ({
      id: u.id,
      name: u.name,
      username: u.username,
      role: u.role,
      isOwner: u.isOwner,
      isActive: u.isActive,
      createdAt: u.createdAt,
    })),

    // Payments
    payments: (sub?.payments || []).map((p) => ({
      id: p.id,
      amountCents: p.amountCents,
      currency: p.currency,
      status: p.status,
      createdAt: p.createdAt,
      paidAt: p.paidAt,
      proofsCount: p.proofs.length,
    })),

    // Products
    products: account.products.map((p) => ({
      id: p.id,
      productId: p.productId,
      name: p.name,
      sku: p.sku,
      priceCents: p.priceCents,
      costCents: p.costCents,
      stock: p.stock instanceof Decimal ? p.stock.toNumber() : Number(p.stock),
      productKind: p.productKind,
      unit: p.unit,
      isActive: p.isActive,
      createdAt: p.createdAt,
    })),

    // Billing Plan
    billingPlanId: sub?.billingPlanId || null,
    billingPlanName: sub?.billingPlan?.name || null,

    // Onboarding
    onboardingCompleted: Boolean(onboarding?.completedAt),
    onboardingCompletedAt: onboarding?.completedAt ?? null,
    onboardingFirstSeenAt: onboarding?.firstSeenAt ?? null,
    onboardingLastSkippedAt: onboarding?.lastSkippedAt ?? null,
    onboardingFirstProductId: onboarding?.firstProductId ?? null,
    onboardingFirstSaleId: onboarding?.firstSaleId ?? null,
  }
}

// ==========================================
// ACCOUNT ACTIONS
// ==========================================

export async function deleteAccount(accountId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const admin = await getCurrentSuperAdmin()
    if (!admin || !admin.canDeleteAccounts) {
      return { success: false, error: "No tienes permisos para eliminar cuentas" }
    }

    // Verificar que existe
    const account = await prisma.account.findUnique({
      where: { id: accountId },
    })

    if (!account) {
      return { success: false, error: "Cuenta no encontrada" }
    }

    // Eliminar en orden para evitar errores de llaves foráneas por userId
    await prisma.$transaction(async (tx) => {
      // 1) Eliminar entidades dependientes de usuarios (sin onDelete cascade)
      await tx.return.deleteMany({ where: { accountId } })
      await tx.payment.deleteMany({
        where: {
          ar: {
            sale: {
              accountId,
            },
          },
        },
      })
      await tx.purchase.deleteMany({ where: { accountId } })
      await tx.operatingExpense.deleteMany({ where: { accountId } })
      await tx.quote.deleteMany({ where: { accountId } })
      await tx.sale.deleteMany({ where: { accountId } })
      await tx.productRecipeItem.deleteMany({
        where: {
          OR: [
            { product: { accountId } },
            { ingredient: { accountId } },
          ],
        },
      })

      // 2) Eliminar usuarios del account
      await tx.user.deleteMany({ where: { accountId } })

      // 3) Eliminar el account (cascade eliminará lo restante)
      await tx.account.delete({ where: { id: accountId } })
    })

    await logSuperAdminAction(admin.id, "deleted_account", {
      targetAccountId: accountId,
      metadata: { accountName: account.name },
    })

    revalidatePath("/super-admin")
    revalidatePath("/super-admin/accounts")

    return { success: true }
  } catch (error) {
    console.error("Error deleting account:", error)
    return { success: false, error: "Error al eliminar la cuenta" }
  }
}

// ==========================================
// TEMP TEST HELPERS
// ==========================================

export async function simulateTrialExpiry(
  accountId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const admin = await getCurrentSuperAdmin()
    if (!admin || !admin.canManageAccounts) {
      return { success: false, error: "No tienes permisos para modificar suscripciones" }
    }

    const subscription = await prisma.billingSubscription.findUnique({
      where: { accountId },
    })

    if (!subscription) {
      return { success: false, error: "Suscripción no encontrada" }
    }

    const now = new Date()
    const trialStartedAt = new Date(now)
    trialStartedAt.setDate(trialStartedAt.getDate() - 16)
    const trialEndsAt = new Date(now)
    trialEndsAt.setDate(trialEndsAt.getDate() - 1)

    await prisma.billingSubscription.update({
      where: { accountId },
      data: {
        status: "TRIALING",
        trialStartedAt,
        trialEndsAt,
        currentPeriodStartsAt: null,
        currentPeriodEndsAt: null,
        graceEndsAt: null,
      },
    })

    await logSuperAdminAction(admin.id, "simulated_trial_expiry", {
      targetAccountId: accountId,
      metadata: { trialStartedAt, trialEndsAt },
    })

    revalidatePath("/super-admin")
    revalidatePath("/super-admin/accounts")
    revalidatePath(`/super-admin/accounts/${accountId}`)

    return { success: true }
  } catch (error) {
    console.error("Error simulating trial expiry:", error)
    return { success: false, error: "Error al simular la expiración del trial" }
  }
}

export async function runBillingEngine(): Promise<{ success: boolean; error?: string }> {
  try {
    const admin = await getCurrentSuperAdmin()
    if (!admin || !admin.canManageAccounts) {
      return { success: false, error: "No tienes permisos para ejecutar el engine" }
    }

    const result = await processBillingEngine()

    await logSuperAdminAction(admin.id, "ran_billing_engine", {
      metadata: result,
    })

    revalidatePath("/super-admin")
    revalidatePath("/super-admin/accounts")

    return { success: true }
  } catch (error) {
    console.error("Error running billing engine:", error)
    return { success: false, error: "Error al ejecutar el billing engine" }
  }
}
