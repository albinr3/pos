"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { formatDateDO, formatDateTimeDO } from "@/lib/date-time"
import {
  ArrowLeft,
  Building2,
  CreditCard,
  Users,
  Package,
  ShoppingCart,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Shield,
  FileText,
  Loader2,
  MoreHorizontal,
  Play,
  Pause,
  Trash2,
  Key,
  Search,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import type { AccountDetail } from "../actions"
import { deleteAccount, simulateTrialExpiry, runBillingEngine, resetUserPassword, resetPrimaryAccountPassword } from "../actions"
import { updateSubscriptionStatus, extendTrial } from "../../actions"
import { assignPlanToAccount, getActiveBillingPlans } from "../../plans/actions"

function formatMoney(cents: number, currency: "DOP" | "USD"): string {
  const amount = cents / 100
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(amount)
  }
  return new Intl.NumberFormat("es-DO", { style: "currency", currency: "DOP" }).format(amount)
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string; icon: React.ReactNode }> = {
    TRIALING: { label: "Trial", className: "bg-blue-100 text-blue-800 border-blue-300", icon: <Clock className="h-3 w-3" /> },
    ACTIVE: { label: "Activo", className: "bg-green-100 text-green-800 border-green-300", icon: <CheckCircle className="h-3 w-3" /> },
    GRACE: { label: "Gracia", className: "bg-yellow-100 text-yellow-800 border-yellow-300", icon: <AlertCircle className="h-3 w-3" /> },
    BLOCKED: { label: "Bloqueado", className: "bg-red-100 text-red-800 border-red-300", icon: <XCircle className="h-3 w-3" /> },
    CANCELED: { label: "Cancelado", className: "bg-gray-100 text-gray-800 border-gray-300", icon: <XCircle className="h-3 w-3" /> },
  }
  const { label, className, icon } = config[status] || { label: status, className: "", icon: null }
  return (
    <Badge className={`${className} flex items-center gap-1`}>
      {icon}
      {label}
    </Badge>
  )
}

function PaymentStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string }> = {
    PENDING: { label: "Pendiente", className: "bg-yellow-100 text-yellow-800" },
    PAID: { label: "Pagado", className: "bg-green-100 text-green-800" },
    FAILED: { label: "Fallido", className: "bg-red-100 text-red-800" },
    REJECTED: { label: "Rechazado", className: "bg-red-100 text-red-800" },
  }
  const { label, className } = config[status] || { label: status, className: "" }
  return <Badge className={className}>{label}</Badge>
}

function getRegistrationMethodLabel(method: AccountDetail["registeredWithMethod"]): string {
  if (method === "GOOGLE") return "Google"
  if (method === "EMAIL") return "Correo"
  if (method === "WHATSAPP") return "WhatsApp"
  return "—"
}

function getRegistrationDeviceLabel(device: AccountDetail["registeredFromDevice"]): string {
  if (device === "DESKTOP") return "Desktop"
  if (device === "MOBILE") return "Móvil"
  return "—"
}

const PRODUCT_KIND_LABELS: Record<string, string> = {
  BASIC: "Básico",
  MEASURED: "Medido",
  RECIPE: "Receta",
}

function ProductKindBadge({ kind }: { kind: string }) {
  const label = PRODUCT_KIND_LABELS[kind] || kind
  const className =
    kind === "RECIPE"
      ? "bg-purple-100 text-purple-800"
      : kind === "MEASURED"
        ? "bg-blue-100 text-blue-800"
        : "bg-gray-100 text-gray-800"
  return <Badge className={className}>{label}</Badge>
}

function formatProductPrice(cents: number) {
  return new Intl.NumberFormat("es-DO", { style: "currency", currency: "DOP" }).format(cents / 100)
}

function ProductsSection({ products }: { products: AccountDetail["products"] }) {
  const [search, setSearch] = useState("")

  const filtered = search.trim()
    ? products.filter((p) => {
        const q = search.trim().toLowerCase()
        return (
          p.name.toLowerCase().includes(q) ||
          (p.sku && p.sku.toLowerCase().includes(q)) ||
          String(p.productId).includes(q)
        )
      })
    : products

  const activeCount = products.filter((p) => p.isActive).length
  const inactiveCount = products.length - activeCount

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Productos ({products.length})
            </CardTitle>
            <CardDescription>
              {activeCount} activos{inactiveCount > 0 ? `, ${inactiveCount} inactivos` : ""}
            </CardDescription>
          </div>
        </div>
        <div className="relative mt-2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nombre, SKU o ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </CardHeader>
      <CardContent>
        {filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            {search.trim() ? "No se encontraron productos" : "No hay productos registrados"}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[60px]">ID</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead className="text-right">Precio</TableHead>
                  <TableHead className="text-right">Costo</TableHead>
                  <TableHead className="text-right">Stock</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((product) => (
                  <TableRow key={product.id} className={!product.isActive ? "opacity-50" : undefined}>
                    <TableCell className="font-mono text-muted-foreground">{product.productId}</TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell className="text-muted-foreground">{product.sku || "—"}</TableCell>
                    <TableCell className="text-right">{formatProductPrice(product.priceCents)}</TableCell>
                    <TableCell className="text-right">{formatProductPrice(product.costCents)}</TableCell>
                    <TableCell className="text-right">
                      {product.productKind === "RECIPE" ? "—" : product.stock}
                    </TableCell>
                    <TableCell>
                      <ProductKindBadge kind={product.productKind} />
                    </TableCell>
                    <TableCell>
                      {product.isActive ? (
                        <Badge className="bg-green-100 text-green-800">Activo</Badge>
                      ) : (
                        <Badge variant="destructive">Inactivo</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

type BillingPlanOption = {
  id: string
  name: string
  priceUsdCents: number
  priceDopCents: number
}

export function AccountDetailClient({ account }: { account: AccountDetail }) {
  const router = useRouter()
  const { toast } = useToast()
  const accountPhone = account.companyPhone || account.billingPhone || null
  const [isLoading, setIsLoading] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showStatusDialog, setShowStatusDialog] = useState(false)
  const [newStatus, setNewStatus] = useState(account.status)

  // Password Reset
  const [showPasswordDialog, setShowPasswordDialog] = useState(false)
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null)
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isResetting, setIsResetting] = useState(false)
  const [showPrimaryPasswordDialog, setShowPrimaryPasswordDialog] = useState(false)
  const [newPrimaryPassword, setNewPrimaryPassword] = useState("")
  const [confirmPrimaryPassword, setConfirmPrimaryPassword] = useState("")
  const [isResettingPrimaryPassword, setIsResettingPrimaryPassword] = useState(false)

  // Plan selection
  const [availablePlans, setAvailablePlans] = useState<BillingPlanOption[]>([])
  const [selectedPlanId, setSelectedPlanId] = useState<string>(account.billingPlanId || "")
  const [isLoadingPlans, setIsLoadingPlans] = useState(true)
  const [isChangingPlan, setIsChangingPlan] = useState(false)

  // Load available plans on mount
  useEffect(() => {
    async function loadPlans() {
      try {
        const plans = await getActiveBillingPlans()
        setAvailablePlans(plans)
      } catch (error) {
        console.error("Error loading plans:", error)
      } finally {
        setIsLoadingPlans(false)
      }
    }
    loadPlans()
  }, [])

  const handlePlanChange = async (planId: string) => {
    if (planId === account.billingPlanId) return

    setIsChangingPlan(true)
    try {
      const result = await assignPlanToAccount(account.id, planId)
      if (result.success) {
        const plan = availablePlans.find(p => p.id === planId)
        toast({
          title: "Plan actualizado",
          description: `Se asignó el plan "${plan?.name}" a esta cuenta`,
        })
        setSelectedPlanId(planId)
        router.refresh()
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al cambiar el plan", variant: "destructive" })
    } finally {
      setIsChangingPlan(false)
    }
  }

  const handleStatusChange = async () => {
    setIsLoading(true)
    try {
      const result = await updateSubscriptionStatus(account.id, newStatus)
      if (result.success) {
        toast({ title: "Estado actualizado", description: `El estado ha sido cambiado a ${newStatus}` })
        router.refresh()
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al actualizar el estado", variant: "destructive" })
    } finally {
      setIsLoading(false)
      setShowStatusDialog(false)
    }
  }

  const handleExtendTrial = async (days: number) => {
    setIsLoading(true)
    try {
      const result = await extendTrial(account.id, days)
      if (result.success) {
        toast({ title: "Trial extendido", description: `Se han agregado ${days} días al trial` })
        router.refresh()
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al extender el trial", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async () => {
    setIsLoading(true)
    try {
      const result = await deleteAccount(account.id)
      if (result.success) {
        toast({ title: "Cuenta eliminada", description: "La cuenta ha sido eliminada" })
        router.push("/super-admin/accounts")
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al eliminar la cuenta", variant: "destructive" })
    } finally {
      setIsLoading(false)
      setShowDeleteDialog(false)
    }
  }

  const handleSimulateTrialExpiry = async () => {
    setIsLoading(true)
    try {
      const result = await simulateTrialExpiry(account.id)
      if (result.success) {
        toast({
          title: "Trial expirado (simulado)",
          description: "La cuenta fue marcada como trial vencido y procesada.",
        })
        router.refresh()
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al simular expiración", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const handleRunBillingEngine = async () => {
    setIsLoading(true)
    try {
      const result = await runBillingEngine()
      if (result.success) {
        toast({
          title: "Billing engine ejecutado",
          description: "Se procesaron las suscripciones.",
        })
        router.refresh()
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al ejecutar el billing engine", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePasswordReset = async () => {
    if (!selectedUserId || !newPassword) return
    if (newPassword.trim().length < 6) {
      toast({
        title: "Contraseña inválida",
        description: "La contraseña debe tener al menos 6 caracteres.",
        variant: "destructive",
      })
      return
    }
    if (newPassword !== confirmPassword) {
      toast({
        title: "Las contraseñas no coinciden",
        description: "Verifica la confirmación de contraseña.",
        variant: "destructive",
      })
      return
    }

    setIsResetting(true)
    try {
      const result = await resetUserPassword(selectedUserId, newPassword)
      if (result.success) {
        toast({ title: "Contraseña actualizada", description: "La contraseña ha sido restablecida correctamente." })
        setShowPasswordDialog(false)
        setNewPassword("")
        setConfirmPassword("")
        setSelectedUserId(null)
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({ title: "Error", description: "Error al restablecer contraseña", variant: "destructive" })
    } finally {
      setIsResetting(false)
    }
  }

  const handlePrimaryPasswordReset = async () => {
    if (newPrimaryPassword.trim().length < 8) {
      toast({
        title: "Contraseña inválida",
        description: "La contraseña principal debe tener al menos 8 caracteres.",
        variant: "destructive",
      })
      return
    }
    if (newPrimaryPassword !== confirmPrimaryPassword) {
      toast({
        title: "Las contraseñas no coinciden",
        description: "Verifica la confirmación de contraseña.",
        variant: "destructive",
      })
      return
    }

    setIsResettingPrimaryPassword(true)
    try {
      const result = await resetPrimaryAccountPassword(account.id, newPrimaryPassword)
      if (result.success) {
        toast({
          title: "Contraseña principal actualizada",
          description: "Se cambió la contraseña del acceso principal de la cuenta.",
        })
        setShowPrimaryPasswordDialog(false)
        setNewPrimaryPassword("")
        setConfirmPrimaryPassword("")
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } catch {
      toast({
        title: "Error",
        description: "Error al cambiar la contraseña del acceso principal",
        variant: "destructive",
      })
    } finally {
      setIsResettingPrimaryPassword(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/super-admin/accounts">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Building2 className="h-8 w-8" />
              {account.name}
            </h1>
            <p className="text-muted-foreground">ID: {account.id}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={account.status} />
          <Button variant="outline" onClick={() => setShowStatusDialog(true)}>
            <Shield className="mr-2 h-4 w-4" />
            Cambiar estado
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setNewStatus("BLOCKED")
              setShowStatusDialog(true)
            }}
          >
            <Pause className="mr-2 h-4 w-4" />
            Bloquear
          </Button>
          <Button
            variant="destructive"
            onClick={() => setShowDeleteDialog(true)}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Eliminar
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowStatusDialog(true)}>
                <Shield className="mr-2 h-4 w-4" />
                Cambiar estado
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExtendTrial(7)}>
                <Play className="mr-2 h-4 w-4" />
                Extender trial (+7 días)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExtendTrial(3)}>
                <Play className="mr-2 h-4 w-4" />
                Extender trial (+3 días)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExtendTrial(15)}>
                <Play className="mr-2 h-4 w-4" />
                Extender trial (+15 días)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleSimulateTrialExpiry}>
                <Clock className="mr-2 h-4 w-4" />
                Simular fin de trial (TEST)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleRunBillingEngine}>
                <Play className="mr-2 h-4 w-4" />
                Ejecutar billing engine (TEST)
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => setShowDeleteDialog(true)}
                className="text-destructive"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Eliminar cuenta
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Info principal */}
        <div className="lg:col-span-2 space-y-6">
          {/* Suscripción */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Suscripción
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Plan Selection */}
              <div className="p-4 border rounded-lg bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-medium">Plan de Precios</p>
                  {account.billingPlanName && (
                    <Badge variant="secondary">{account.billingPlanName}</Badge>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <Select
                    value={selectedPlanId}
                    onValueChange={handlePlanChange}
                    disabled={isLoadingPlans || isChangingPlan}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder={isLoadingPlans ? "Cargando planes..." : "Seleccionar plan"} />
                    </SelectTrigger>
                    <SelectContent>
                      {availablePlans.map((plan) => (
                        <SelectItem key={plan.id} value={plan.id}>
                          {plan.name} - {formatMoney(plan.priceUsdCents, "USD")} / {formatMoney(plan.priceDopCents, "DOP")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {isChangingPlan && <Loader2 className="h-4 w-4 animate-spin" />}
                </div>
                {!account.billingPlanId && (
                  <p className="text-xs text-yellow-600 mt-2">
                    Esta cuenta no tiene un plan asignado. Se usan los precios por defecto.
                  </p>
                )}
              </div>

              <Separator />

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="text-sm text-muted-foreground">Estado</p>
                  <StatusBadge status={account.status} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Precio mensual</p>
                  <p className="font-medium">
                    {formatMoney(
                      account.currency === "USD" ? account.priceUsdCents : account.priceDopCents,
                      account.currency
                    )}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Método de pago</p>
                  <Badge variant="outline">
                    {account.provider === "MANUAL" ? "Transferencia" : "Tarjeta"}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Moneda</p>
                  <Badge variant="outline">{account.currency}</Badge>
                </div>
                {account.trialEndsAt && (
                  <div>
                    <p className="text-sm text-muted-foreground">Trial termina</p>
                    <p className="font-medium">
                      {formatDateTimeDO(account.trialEndsAt, { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                )}
                {account.currentPeriodEndsAt && (
                  <div>
                    <p className="text-sm text-muted-foreground">Período actual termina</p>
                    <p className="font-medium">
                      {formatDateTimeDO(account.currentPeriodEndsAt, { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                )}
                {account.graceEndsAt && (
                  <div>
                    <p className="text-sm text-muted-foreground">Gracia termina</p>
                    <p className="font-medium text-yellow-600">
                      {formatDateTimeDO(account.graceEndsAt, { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Datos del negocio */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Datos del negocio
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="text-sm text-muted-foreground">Nombre</p>
                  <p className="font-medium">{account.companyName || account.name}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Teléfono</p>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{accountPhone || "No registrado"}</span>
                  </div>
                </div>
                {account.companyAddress && (
                  <div className="flex items-center gap-2 md:col-span-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{account.companyAddress}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Registrado {formatDateDO(account.createdAt, { day: "2-digit", month: "2-digit", year: "numeric" })}</span>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Registro con</p>
                  <p className="font-medium">{getRegistrationMethodLabel(account.registeredWithMethod)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Registro desde</p>
                  <p className="font-medium">{getRegistrationDeviceLabel(account.registeredFromDevice)}</p>
                </div>
                <div className="md:col-span-2">
                  <div className="rounded-lg border p-3 bg-muted/30">
                    <p className="text-sm font-medium">Acceso principal (cuenta general)</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Usuario de autenticación: <span className="font-mono">{account.clerkUserId}</span>
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => setShowPrimaryPasswordDialog(true)}
                    >
                      <Key className="mr-2 h-4 w-4" />
                      Cambiar contraseña principal
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Perfil de facturación */}
          {(account.billingLegalName || account.billingEmail) && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Perfil de facturación
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  {account.billingLegalName && (
                    <div>
                      <p className="text-sm text-muted-foreground">Nombre legal</p>
                      <p className="font-medium">{account.billingLegalName}</p>
                    </div>
                  )}
                  {account.billingTaxId && (
                    <div>
                      <p className="text-sm text-muted-foreground">RNC/Cédula</p>
                      <p className="font-medium">{account.billingTaxId}</p>
                    </div>
                  )}
                  {account.billingEmail && (
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{account.billingEmail}</span>
                    </div>
                  )}
                  {account.billingPhone && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{account.billingPhone}</span>
                    </div>
                  )}
                  {account.billingAddress && (
                    <div className="flex items-center gap-2 md:col-span-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{account.billingAddress}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Historial de pagos */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Historial de pagos
              </CardTitle>
              <CardDescription>{account.payments.length} pagos registrados</CardDescription>
            </CardHeader>
            <CardContent>
              {account.payments.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No hay pagos registrados
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Monto</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Comprobantes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {account.payments.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell>
                          {formatDateTimeDO(payment.createdAt, { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                        </TableCell>
                        <TableCell>{formatMoney(payment.amountCents, payment.currency)}</TableCell>
                        <TableCell>
                          <PaymentStatusBadge status={payment.status} />
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{payment.proofsCount} archivos</Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Productos */}
          <ProductsSection products={account.products} />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Onboarding</CardTitle>
              <CardDescription>Estado del recorrido inicial de la cuenta</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Estado</span>
                {account.onboardingCompleted ? (
                  <Badge className="bg-green-100 text-green-800 border-green-300">Completado</Badge>
                ) : (
                  <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendiente</Badge>
                )}
              </div>
              <Separator />
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Primera visita onboarding</p>
                <p className="text-sm font-medium">
                  {account.onboardingFirstSeenAt
                    ? formatDateTimeDO(account.onboardingFirstSeenAt, {
                        day: "2-digit",
                        month: "2-digit",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : "Sin registro"}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Último salto del tutorial</p>
                <p className="text-sm font-medium">
                  {account.onboardingLastSkippedAt
                    ? formatDateTimeDO(account.onboardingLastSkippedAt, {
                        day: "2-digit",
                        month: "2-digit",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : "Nunca"}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Completado en</p>
                <p className="text-sm font-medium">
                  {account.onboardingCompletedAt
                    ? formatDateTimeDO(account.onboardingCompletedAt, {
                        day: "2-digit",
                        month: "2-digit",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : "No completado"}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Estadísticas */}
          <Card>
            <CardHeader>
              <CardTitle>Uso del sistema</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  Usuarios
                </span>
                <span className="font-medium">{account.usersCount}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm">
                  <Package className="h-4 w-4 text-muted-foreground" />
                  Productos
                </span>
                <span className="font-medium">{account.productsCount}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm">
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                  Ventas
                </span>
                <span className="font-medium">{account.salesCount}</span>
              </div>
            </CardContent>
          </Card>

          {/* Usuarios */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Usuarios ({account.users.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {account.users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{user.name}</p>
                      <p className="text-xs text-muted-foreground">@{user.username}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {user.isOwner && (
                        <Badge className="bg-purple-100 text-purple-800 text-xs">Dueño</Badge>
                      )}
                      <Badge variant="outline" className="text-xs">{user.role}</Badge>
                      {!user.isActive && (
                        <Badge variant="destructive" className="text-xs">Inactivo</Badge>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        title="Cambiar contraseña"
                        onClick={() => {
                          setSelectedUserId(user.id)
                          setShowPasswordDialog(true)
                        }}
                      >
                        <Key className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Dialog para cambiar estado */}
      <AlertDialog open={showStatusDialog} onOpenChange={setShowStatusDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cambiar estado de suscripción</AlertDialogTitle>
            <AlertDialogDescription>
              Selecciona el nuevo estado para esta cuenta.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Select value={newStatus} onValueChange={(v) => setNewStatus(v as typeof newStatus)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="TRIALING">Trial</SelectItem>
              <SelectItem value="ACTIVE">Activo</SelectItem>
              <SelectItem value="GRACE">Gracia</SelectItem>
              <SelectItem value="BLOCKED">Bloqueado</SelectItem>
              <SelectItem value="CANCELED">Cancelado</SelectItem>
            </SelectContent>
          </Select>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleStatusChange} disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Guardar cambios
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog para eliminar */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar cuenta?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Se eliminarán todos los datos de la cuenta
              incluyendo usuarios, productos, ventas y configuraciones.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isLoading}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Eliminar cuenta
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog para resetear password */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar contraseña</DialogTitle>
            <DialogDescription>
              Ingresa la nueva contraseña para el usuario. Esta acción es inmediata.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="new-password">Nueva contraseña</Label>
              <Input
                id="new-password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Mínimo 6 caracteres"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="confirm-password">Confirmar contraseña</Label>
              <Input
                id="confirm-password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repite la nueva contraseña"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowPasswordDialog(false)
                setNewPassword("")
                setConfirmPassword("")
                setSelectedUserId(null)
              }}
            >
              Cancelar
            </Button>
            <Button
              onClick={handlePasswordReset}
              disabled={isResetting || newPassword.trim().length < 6 || confirmPassword.length === 0}
            >
              {isResetting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Guardar contraseña
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showPrimaryPasswordDialog} onOpenChange={setShowPrimaryPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar contraseña principal</DialogTitle>
            <DialogDescription>
              Esta contraseña corresponde al acceso general de la cuenta (correo/Google en Clerk).
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="new-primary-password">Nueva contraseña principal</Label>
              <Input
                id="new-primary-password"
                type="password"
                value={newPrimaryPassword}
                onChange={(e) => setNewPrimaryPassword(e.target.value)}
                placeholder="Mínimo 8 caracteres"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="confirm-primary-password">Confirmar contraseña</Label>
              <Input
                id="confirm-primary-password"
                type="password"
                value={confirmPrimaryPassword}
                onChange={(e) => setConfirmPrimaryPassword(e.target.value)}
                placeholder="Repite la nueva contraseña"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowPrimaryPasswordDialog(false)
                setNewPrimaryPassword("")
                setConfirmPrimaryPassword("")
              }}
            >
              Cancelar
            </Button>
            <Button
              onClick={handlePrimaryPasswordReset}
              disabled={
                isResettingPrimaryPassword ||
                newPrimaryPassword.trim().length < 8 ||
                confirmPrimaryPassword.length === 0
              }
            >
              {isResettingPrimaryPassword && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Guardar contraseña principal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div >
  )
}
