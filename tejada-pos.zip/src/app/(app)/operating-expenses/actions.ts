"use server"

import { revalidatePath } from "next/cache"
import { prisma } from "@/lib/db"
import { startOfDay, endOfDay, parseDateParam } from "@/lib/dates"
import { getCurrentUser } from "@/lib/auth"
import { logAuditEvent } from "@/lib/audit-log"
import { ensurePermission } from "@/lib/permission-guard"
import { PaymentMethod } from "@prisma/client"
import { ensureDefaultTreasuryAccount, requireTreasuryAccount } from "@/lib/treasury"

export async function listOperatingExpenses(input?: { from?: string; to?: string }) {
  const user = await getCurrentUser()
  if (!user) throw new Error("No autenticado")

  const fromDate = parseDateParam(input?.from) ?? new Date()
  const toDate = parseDateParam(input?.to) ?? fromDate

  const from = startOfDay(fromDate)
  const to = endOfDay(toDate)

  return prisma.operatingExpense.findMany({
    where: {
      accountId: user.accountId,
      expenseDate: { gte: from, lte: to },
    },
    orderBy: { expenseDate: "desc" },
    include: {
      user: {
        select: { name: true, username: true },
      },
    },
    take: 500,
  })
}

export async function listOperatingExpenseCategories() {
  const user = await getCurrentUser()
  if (!user) throw new Error("No autenticado")

  const rows = await prisma.operatingExpense.findMany({
    where: {
      accountId: user.accountId,
      category: { not: null },
    },
    select: { category: true },
    distinct: ["category"],
    orderBy: { category: "asc" },
    take: 200,
  })

  return rows
    .map((row) => row.category?.trim())
    .filter((value): value is string => Boolean(value))
}

export async function createOperatingExpense(input: {
  description: string
  amountCents: number
  paymentMethod?: PaymentMethod | null
  treasuryAccountId?: string | null
  expenseDate?: Date
  category?: string | null
  notes?: string | null
}) {
  const currentUser = await getCurrentUser()
  if (!currentUser) throw new Error("No autenticado")
  await ensurePermission(currentUser, "canManageExpenses", {
    message: "No tienes permiso para registrar gastos",
    resourceType: "OperatingExpense",
  })

  const description = input.description.trim()
  if (!description) throw new Error("La descripcion es requerida")
  if (input.amountCents <= 0) throw new Error("El monto debe ser mayor a 0")
  if (input.paymentMethod === PaymentMethod.DIVIDIR_PAGO) {
    throw new Error("Dividir pago no es un método válido para gastos operativos")
  }

  const treasuryAccount = input.treasuryAccountId?.trim()
    ? await requireTreasuryAccount(prisma, {
        accountId: currentUser.accountId,
        treasuryAccountId: input.treasuryAccountId.trim(),
        requireActive: true,
        message: "La cuenta de tesorería seleccionada no existe o está inactiva.",
      })
    : await ensureDefaultTreasuryAccount(prisma, currentUser.accountId, currentUser.id)

  const created = await prisma.operatingExpense.create({
    data: {
      accountId: currentUser.accountId,
      description,
      amountCents: input.amountCents,
      paymentMethod: input.paymentMethod ?? PaymentMethod.OTRO,
      treasuryAccountId: treasuryAccount.id,
      expenseDate: input.expenseDate ?? new Date(),
      category: input.category?.trim() || null,
      notes: input.notes?.trim() || null,
      userId: currentUser.id,
    },
  })

  await logAuditEvent({
    accountId: currentUser.accountId,
    userId: currentUser.id,
    userEmail: currentUser.email ?? null,
    userUsername: currentUser.username ?? null,
    action: "OPERATING_EXPENSE_CREATED",
    resourceType: "OperatingExpense",
    resourceId: created.id,
    details: {
      description,
      amountCents: input.amountCents,
      expenseDate: created.expenseDate.toISOString(),
      category: input.category?.trim() || null,
    },
  })

  revalidatePath("/operating-expenses")
  revalidatePath("/reports/profit")
  revalidatePath("/dashboard")
}

export async function updateOperatingExpense(input: {
  id: string
  description: string
  amountCents: number
  paymentMethod?: PaymentMethod | null
  treasuryAccountId?: string | null
  expenseDate: Date
  category?: string | null
  notes?: string | null
}) {
  const user = await getCurrentUser()
  if (!user) throw new Error("No autenticado")
  await ensurePermission(user, "canManageExpenses", {
    message: "No tienes permiso para registrar gastos",
    resourceType: "OperatingExpense",
    resourceId: input.id,
  })

  const description = input.description.trim()
  if (!description) throw new Error("La descripción es requerida")
  if (input.amountCents <= 0) throw new Error("El monto debe ser mayor a 0")
  if (input.paymentMethod === PaymentMethod.DIVIDIR_PAGO) {
    throw new Error("Dividir pago no es un método válido para gastos operativos")
  }

  const existing = await prisma.operatingExpense.findFirst({ 
    where: { accountId: user.accountId, id: input.id } 
  })
  if (!existing) throw new Error("Gasto operativo no encontrado")

  const treasuryAccount = input.treasuryAccountId?.trim()
    ? await requireTreasuryAccount(prisma, {
        accountId: user.accountId,
        treasuryAccountId: input.treasuryAccountId.trim(),
        requireActive: true,
        message: "La cuenta de tesorería seleccionada no existe o está inactiva.",
      })
    : existing.treasuryAccountId
      ? await requireTreasuryAccount(prisma, {
          accountId: user.accountId,
          treasuryAccountId: existing.treasuryAccountId,
          message: "La cuenta de tesorería del gasto no existe.",
        })
      : await ensureDefaultTreasuryAccount(prisma, user.accountId, user.id)

  await prisma.operatingExpense.update({
    where: { id: input.id },
    data: {
      description,
      amountCents: input.amountCents,
      paymentMethod: input.paymentMethod ?? existing.paymentMethod ?? PaymentMethod.OTRO,
      treasuryAccountId: treasuryAccount.id,
      expenseDate: input.expenseDate,
      category: input.category?.trim() || null,
      notes: input.notes?.trim() || null,
    },
  })

  await logAuditEvent({
    accountId: user.accountId,
    userId: user.id,
    userEmail: user.email ?? null,
    userUsername: user.username ?? null,
    action: "OPERATING_EXPENSE_EDITED",
    resourceType: "OperatingExpense",
    resourceId: input.id,
    details: {
      description,
      amountCents: input.amountCents,
      expenseDate: input.expenseDate.toISOString(),
      category: input.category?.trim() || null,
    },
  })

  revalidatePath("/operating-expenses")
  revalidatePath("/reports/profit")
  revalidatePath("/dashboard")
}

export async function deleteOperatingExpense(id: string) {
  const user = await getCurrentUser()
  if (!user) throw new Error("No autenticado")
  await ensurePermission(user, "canCancelExpenses", {
    message: "No tienes permiso para anular gastos",
    resourceType: "OperatingExpense",
    resourceId: id,
  })

  const existing = await prisma.operatingExpense.findFirst({ 
    where: { accountId: user.accountId, id } 
  })
  if (!existing) throw new Error("Gasto operativo no encontrado")

  await prisma.operatingExpense.delete({ where: { id } })

  await logAuditEvent({
    accountId: user.accountId,
    userId: user.id,
    userEmail: user.email ?? null,
    userUsername: user.username ?? null,
    action: "OPERATING_EXPENSE_DELETED",
    resourceType: "OperatingExpense",
    resourceId: existing.id,
    details: {
      description: existing.description,
      amountCents: existing.amountCents,
      expenseDate: existing.expenseDate.toISOString(),
      category: existing.category,
    },
  })

  revalidatePath("/operating-expenses")
  revalidatePath("/reports/profit")
  revalidatePath("/dashboard")
}

export async function getOperatingExpensesTotal(input?: { from?: string; to?: string }) {
  const user = await getCurrentUser()
  if (!user) throw new Error("No autenticado")

  const fromDate = parseDateParam(input?.from) ?? new Date()
  const toDate = parseDateParam(input?.to) ?? fromDate

  const from = startOfDay(fromDate)
  const to = endOfDay(toDate)

  const result = await prisma.operatingExpense.aggregate({
    where: {
      accountId: user.accountId,
      expenseDate: { gte: from, lte: to },
    },
    _sum: { amountCents: true },
    _count: true,
  })

  return {
    totalCents: result._sum.amountCents ?? 0,
    count: result._count ?? 0,
  }
}














