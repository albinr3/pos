import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { formatRD } from "@/lib/money"
import { getCurrentUser } from "@/lib/auth"
import { hasPermission } from "@/lib/permissions"

import { getInventoryReport } from "../actions"
import { InventoryExportClient } from "./inventory-export-client"
import { DownloadPdfButton } from "@/components/app/download-pdf-button"

// Evitar prerender durante el build
export const dynamic = "force-dynamic"

export default async function InventoryReportPage() {
  const user = await getCurrentUser()
  const canViewCosts = user
    ? hasPermission(user, "canViewProductCosts", { allowAdminBypass: false })
    : false
  const data = await getInventoryReport()

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Reporte de inventario</h1>
          <p className="text-sm text-muted-foreground">
            Listado de productos con su costo registrado y total de inventario.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <DownloadPdfButton />
          <InventoryExportClient
            products={data.products}
            totalInventoryCostCents={data.totalInventoryCostCents}
            count={data.count}
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            {canViewCosts 
              ? `Total de inventario en costo: ${formatRD(data.totalInventoryCostCents)} (${data.count} productos)`
              : `Inventario: ${data.count} productos`}
          </CardTitle>
          {canViewCosts && (
            <div className="text-xs text-muted-foreground">
              El costo mostrado es el costo registrado del producto y puede incluir ITBIS segun la configuracion de compras/proveedor.
            </div>
          )}
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-x-auto">
            <Table className="min-w-[700px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Producto</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Proveedor</TableHead>
                      <TableHead className="text-right">Stock</TableHead>
                      {canViewCosts && (
                        <>
                          <TableHead className="text-right">Costo unitario (registrado)</TableHead>
                          <TableHead className="text-right">Costo total (registrado)</TableHead>
                        </>
                      )}
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.products.map((product) => {
                  const totalCostCents = product.costCents * product.stock
                  return (
                    <TableRow key={product.id}>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell>{product.sku ?? "-"}</TableCell>
                      <TableCell>{product.supplier?.name ?? "-"}</TableCell>
                      <TableCell className="text-right">{product.stock}</TableCell>
                      {canViewCosts && (
                        <>
                          <TableCell className="text-right">{formatRD(product.costCents)}</TableCell>
                          <TableCell className="text-right font-medium">{formatRD(totalCostCents)}</TableCell>
                        </>
                      )}
                    </TableRow>
                  )
                })}

                {data.products.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={canViewCosts ? 6 : 4} className="py-10 text-center text-sm text-muted-foreground">
                      No hay productos activos en el inventario.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
