import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { getCurrentUserFromRequest } from "../../_helpers/auth"
import { sanitizePhone, sanitizeString } from "@/lib/sanitize"
import { hasPermissionOrLog } from "@/lib/permission-guard"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

function getErrorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Error inesperado"
}

// GET /api/suppliers/:id - Obtener proveedor
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }

    const { id } = await params
    const supplier = await prisma.supplier.findFirst({
      where: {
        id,
        accountId: user.accountId,
        isActive: true,
      },
    })

    if (!supplier) {
      return NextResponse.json({ error: "Proveedor no encontrado" }, { status: 404 })
    }

    return NextResponse.json({
      id: supplier.id,
      name: supplier.name,
      contactName: supplier.contactName,
      phone: supplier.phone,
      email: supplier.email,
      address: supplier.address,
      notes: supplier.notes,
      discountPercentBp: supplier.discountPercentBp,
      chargesItbis: supplier.chargesItbis,
      itbisRateBp: supplier.itbisRateBp,
      createdAt: supplier.createdAt.toISOString(),
      updatedAt: supplier.updatedAt.toISOString(),
    })
  } catch (error: unknown) {
    console.error("Error en GET /api/suppliers/[id]:", error)
    return NextResponse.json(
      { error: getErrorMessage(error) || "Error al obtener proveedor" },
      { status: 500 }
    )
  }
}

// PUT /api/suppliers/:id - Editar proveedor
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUserFromRequest(request)
    if (!user) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }
    const canManageSuppliers = await hasPermissionOrLog(user, "canManageSuppliers", {
      resourceType: "Supplier",
      details: { endpoint: "/api/suppliers/[id]", method: "PUT" },
    })
    if (!canManageSuppliers) {
      return NextResponse.json({ error: "No tienes permiso para gestionar proveedores" }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json()
    const name = sanitizeString(String(body?.name || ""))
    const contactName =
      typeof body?.contactName === "string" && body.contactName.trim()
        ? sanitizeString(body.contactName)
        : null
    const phone =
      typeof body?.phone === "string" && body.phone.trim()
        ? sanitizePhone(body.phone)
        : null
    const email =
      typeof body?.email === "string" && body.email.trim()
        ? sanitizeString(body.email)
        : null
    const address =
      typeof body?.address === "string" && body.address.trim()
        ? sanitizeString(body.address)
        : null
    const notes =
      typeof body?.notes === "string" && body.notes.trim()
        ? sanitizeString(body.notes)
        : null
    const discountPercentBp = Number.isFinite(Number(body?.discountPercentBp))
      ? Number(body.discountPercentBp)
      : 0
    const chargesItbis = Boolean(body?.chargesItbis)
    const itbisRateBp = chargesItbis
      ? Math.min(10000, Math.max(0, Math.round(Number(body?.itbisRateBp ?? 1800))))
      : null

    if (!name) {
      return NextResponse.json({ error: "El nombre es requerido" }, { status: 400 })
    }

    const exists = await prisma.supplier.findFirst({
      where: { id, accountId: user.accountId, isActive: true },
      select: { id: true },
    })
    if (!exists) {
      return NextResponse.json({ error: "Proveedor no encontrado" }, { status: 404 })
    }

    const duplicate = await prisma.supplier.findFirst({
      where: {
        accountId: user.accountId,
        isActive: true,
        id: { not: id },
        name: { equals: name, mode: "insensitive" },
      },
      select: { id: true },
    })
    if (duplicate) {
      return NextResponse.json(
        { error: "Ya existe un proveedor con ese nombre" },
        { status: 409 }
      )
    }

    const updated = await prisma.supplier.update({
      where: { id },
      data: {
        name,
        contactName,
        phone,
        email,
        address,
        notes,
        discountPercentBp,
        chargesItbis,
        itbisRateBp,
      },
    })

    return NextResponse.json({
      id: updated.id,
      name: updated.name,
      contactName: updated.contactName,
      phone: updated.phone,
      email: updated.email,
      address: updated.address,
      notes: updated.notes,
      discountPercentBp: updated.discountPercentBp,
      chargesItbis: updated.chargesItbis,
      itbisRateBp: updated.itbisRateBp,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    })
  } catch (error: unknown) {
    console.error("Error en PUT /api/suppliers/[id]:", error)
    return NextResponse.json(
      { error: getErrorMessage(error) || "Error al editar proveedor" },
      { status: 500 }
    )
  }
}
