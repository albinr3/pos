import { notFound } from "next/navigation"
import Link from "next/link"

import { getCurrentUser } from "@/lib/auth"
import { formatDateTimeDO } from "@/lib/date-time"
import { formatRD } from "@/lib/money"
import { formatPaymentWithBank } from "@/lib/payment-methods"
import { DownloadReceiptPdfButton } from "@/components/app/download-receipt-pdf-button"
import { PrintButton } from "@/components/app/print-button"
import { Button } from "@/components/ui/button"

// Evitar prerender durante el build
export const dynamic = "force-dynamic"

function fmtDate(d: Date) {
  return formatDateTimeDO(d)
}

export default async function PaymentReceiptPage({
  params,
}: {
  params: Promise<{ paymentId: string }>
}) {
  const { paymentId } = await params

  // Lazy import de Prisma para evitar inicialización durante el build
  const { prisma } = await import("@/lib/db")

  // Obtener usuario actual para filtrar por accountId
  const user = await getCurrentUser()
  if (!user) return notFound()

  const [company, payment] = await Promise.all([
    prisma.companySettings.findFirst({
      where: { accountId: user.accountId }
    }),
    prisma.payment.findFirst({
      where: {
        id: paymentId,
        // Verificar que el payment pertenece a una venta del mismo account
        ar: {
          sale: {
            accountId: user.accountId,
          },
        },
      },
      include: {
        ar: {
          include: {
            customer: true,
            sale: true,
          },
        },
        user: true,
        cancelledUser: { select: { name: true } },
      },
    }),
  ])

  if (!payment) return notFound()
  const receiptPayments = await prisma.payment.findMany({
    where: {
      receiptCode: payment.receiptCode,
      cancelledAt: null,
      ar: {
        sale: {
          accountId: user.accountId,
        },
      },
    },
    include: {
      ar: {
        include: {
          customer: true,
          sale: true,
        },
      },
    },
    orderBy: [{ paidAt: "asc" }, { createdAt: "asc" }],
  })
  const visibleReceiptPayments = receiptPayments.length > 0 ? receiptPayments : [payment]
  const isBatchReceipt = visibleReceiptPayments.length > 1
  const totalReceiptCents = visibleReceiptPayments.reduce((sum, p) => sum + p.amountCents, 0)
  const totalRemainingCents = visibleReceiptPayments.reduce((sum, p) => sum + p.ar.balanceCents, 0)

  return (
    <div className="mx-auto w-[80mm] bg-white p-3 text-[15.5px] leading-4 text-black print-content">
      <style
        dangerouslySetInnerHTML={{
          __html: `
          @page { 
            size: 80mm auto; 
            margin: 0; 
          }
          @media print {
            body { margin: 0; }
            .no-print { display: none !important; }
            /* Configurado para papel térmico: 3 1/8" x 230 ft (80mm wide) */
          }
        `,
        }}
      />

      <div className="no-print mb-2 flex gap-2">
        <PrintButton />
        <DownloadReceiptPdfButton
          filename={`recibo-${payment.receiptCode}`}
        />
        <Button variant="outline" size="sm" asChild>
          <Link href={`/invoices/${payment.ar.sale.invoiceCode}`} target="_blank" rel="noopener noreferrer">
            Factura carta
          </Link>
        </Button>
      </div>

      <div className="text-center">
        {company?.logoUrl && (
          <div className="mb-2 flex justify-center">
            <div className="max-h-12 w-auto overflow-hidden">
              <img src={company.logoUrl} alt="Logo" className="h-12 w-auto object-contain" />
            </div>
          </div>
        )}
        <div className="text-[18px] font-bold">{company?.name || "Mi Negocio"}</div>
        {company?.address && <div>{company.address}</div>}
        {company?.phone && <div>Tel: {company.phone}</div>}
      </div>

      {payment.cancelledAt && (
        <div className="my-2 border-2 border-red-500 bg-red-50 p-2 text-center">
          <div className="text-[18px] font-bold text-red-600">⚠️ RECIBO CANCELADO</div>
          <div className="text-[14.5px] text-red-600">
            Cancelado el {fmtDate(payment.cancelledAt)}
            {payment.cancelledUser && ` por ${payment.cancelledUser.name}`}
          </div>
        </div>
      )}

      <div className="my-4 border-t border-b border-dashed py-3">
        <div className="text-center font-bold text-[18px]">RECIBO DE PAGO</div>
        <div className="mt-3 flex justify-between">
          <span>Recibo:</span>
          <span className="font-bold text-[18px]">{payment.receiptCode}</span>
        </div>
        <div className="flex justify-between mt-1">
          <span>Fecha:</span>
          <span>{fmtDate(payment.paidAt)}</span>
        </div>
        {isBatchReceipt ? (
          <div className="flex justify-between mt-1">
            <span>Facturas:</span>
            <span className="font-semibold">{visibleReceiptPayments.length}</span>
          </div>
        ) : (
          <div className="flex justify-between mt-1">
            <span>Factura:</span>
            <span className="font-semibold">{payment.ar.sale.invoiceCode}</span>
          </div>
        )}
        <div className="mt-2">
          <span className="font-semibold">Cliente:</span> {payment.ar.customer.name}
        </div>
      </div>

      <div className="space-y-3 pb-2">
        <div className="flex justify-between">
          <span>{isBatchReceipt ? "Monto total pagado" : "Monto pagado"}</span>
          <span className="font-semibold">{formatRD(isBatchReceipt ? totalReceiptCents : payment.amountCents)}</span>
        </div>
        <div className="flex justify-between">
          <span>Método</span>
          <span className="font-semibold">{formatPaymentWithBank(payment.method, payment.transferBankName)}</span>
        </div>
        <div className="flex justify-between">
          <span>{isBatchReceipt ? "Pendiente combinado" : "Pendiente"}</span>
          <span className="font-semibold">{formatRD(isBatchReceipt ? totalRemainingCents : payment.ar.balanceCents)}</span>
        </div>
      </div>

      {isBatchReceipt && (
        <div className="mt-4 border-t border-dashed pt-3">
          <div className="mb-2 font-semibold">Desglose por factura</div>
          <div className="space-y-1 text-[14.5px]">
            {visibleReceiptPayments.map((p) => (
              <div key={p.id} className="flex justify-between gap-2">
                <span className="truncate">{p.ar.sale.invoiceCode}</span>
                <span className="font-semibold">{formatRD(p.amountCents)}</span>
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between border-t border-dashed pt-2">
            <span className="font-semibold">Total combinado</span>
            <span className="font-semibold">{formatRD(totalReceiptCents)}</span>
          </div>
        </div>
      )}

      {payment.note && (
        <div className="mt-4 border-t border-dashed pt-3 text-[14.5px] text-neutral-700">
          <div className="font-semibold">Nota</div>
          <div>{payment.note}</div>
        </div>
      )}

      <div className="mt-6 text-center">
        <div className="font-semibold">Gracias</div>
        <div className="text-[14.5px] text-neutral-700">Cajero: {payment.user.name}</div>
      </div>
    </div>
  )
}
