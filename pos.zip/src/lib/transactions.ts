export const TRANSACTION_OPTIONS = {
  timeout: 15000,
  maxWait: 5000,
} as const
